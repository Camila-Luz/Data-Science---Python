from projeto_calculadora import CalculadoraWindows

#@title Funções
def exibir_menu():
    """Exibe o menu da calculadora"""
    print("Calculadora do Windows 10")
    print("Selecione a operação:")
    print("(+). Adição ")
    print("(-). Subtração ")
    print("(*). Multiplicação ")
    print("(/). Divisão ")

    print("(1). Inverter Sinal (+/-)") 
    print("(2). Inverter Acumulador (1/acumulador)") 
    print("(3). Elevar ao quadrado (**= 2)") 
    print("(4). Calcular a raiz quadrada do acumulador (**= 0.5)") 

    print("(C). Limpar Acumulador")
    print("(CE). Carregar backup")
    print("(MS). Salvar Acumulador na Memória")
    print("(MR). Carregar Memória")

    print("(MC). Limpar Memória")
    print("(M+). Somar Memória")
    print("(M-). Subtrair Memória")

    print("(=). Retorna Acumulador")
    print("(0). Sair")

################################################################################

def calcular():
    """Função principal da calculadora"""
    calculadora = CalculadoraWindows()

    # start
    try:
      numero = float(input("Digite o número: "))
      calculadora.somar(numero)

      while True:
          print('\n-------------------------------------------\n')
          exibir_menu()
          operacao = input("Digite a operação desejada: ").upper()

          if operacao == "0":
              print("Calculadora encerrada.")
              break

          if operacao in ["+", "-", "*", "/"]:
              numero = float(input("Digite o número: "))

              if operacao == "+":
                  calculadora.somar(numero)

              elif operacao == "-":
                  calculadora.subtrair(numero)

              elif operacao == "*":
                  calculadora.multiplicar(numero)

              elif operacao == "/":
                  calculadora.dividir(numero)

              print('\n---------------------------------------------\n')
              print(f"Acumulador: [{calculadora.acumulador}]")

          elif operacao == "1":
              calculadora.inverte_sinal()
              print("Sinal do acumulador invertido.")

          elif operacao == "2":
              calculadora.inverte_acumulador()
              print("Número do acumulador invertido")

          elif operacao == "3":
              calculadora.elevar_quadrado()
              print("Acumulador elevado ao quadrado.")

          elif operacao == "4":
              calculadora.raiz_quadrada()
              print("Raiz quadrada do acumulador calculada.")

          elif operacao == "C":
              calculadora.limpar_acumulador()
              print("Acumulador limpo.")

          elif operacao == "CE":
              calculadora.carregar_backup()
              print("Backup carregado no acumulador.")

          elif operacao == "MC":
              calculadora.limpar_memoria()
              print("Memória limpa.")

          elif operacao == "MR":
              calculadora.carregar_memoria()
              print("Memória carregada no acumulador.")

          elif operacao == "MS":
              calculadora.salvar_memoria()
              print("Acumulador salvo na memória.")

          elif operacao == "M+":
              calculadora.somar_memoria()
              print("Acumulador somado à memória.")

          elif operacao == "M-":
              calculadora.subtrair_memoria()
              print("Acumulador subtraído da memória.")


          elif operacao == "=":

              print('\n---------------------------------------------\n')
              print(f"Acumulador: [{calculadora.exibe_acumulador()}]")

          else:
              print("Operação inválida!")
          # salva backup
          calculadora.salvar_backup()
    except:
      print(f'\n (KeyboardInterrupt): O valor do Acumulador é [{calculadora.exibe_acumulador()}]')

################################################################################

#@title Run
calcular()