class CalculadoraWindows:
    def __init__(self):
        self.acumulador: float = 0.0
        self.memoria: float = 0.0
        self.backup: float = 0.0

    def somar(self, numero: float):
        self.acumulador += numero

    def subtrair(self, numero: float):
        self.acumulador -= numero

    def multiplicar(self, numero: float):
        self.acumulador *= numero

    def dividir(self, numero: float):
        # if numero != 0:
        try:
            self.acumulador /= numero
        except:
            print("Erro: divisão por zero!")

    def limpar_acumulador(self):
        self.acumulador = 0.0

    def salvar_memoria(self):
        self.memoria = self.acumulador

    def carregar_memoria(self):
        self.acumulador = self.memoria

    def salvar_backup(self):
        self.backup = self.acumulador

    def carregar_backup(self):
        self.acumulador = self.backup

    def limpar_memoria(self):
        self.memoria = 0.0

    def somar_memoria(self):
        self.memoria += self.acumulador

    def subtrair_memoria(self):
        self.memoria -= self.acumulador

    def inverte_sinal(self):
        self.acumulador *= -1

    def inverte_acumulador(self):
        self.acumulador = 1/self.acumulador

    def elevar_quadrado(self):
        self.acumulador = self.acumulador * self.acumulador

    def raiz_quadrada(self):
        try:
          self.acumulador **= 0.5
        except:
          print("Erro: raiz de número negativo!")

    def exibe_acumulador(self):
        return self.acumulador
